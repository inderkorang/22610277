// logging-middleware/logger.js
const axios = require("axios");

const LOG_ENDPOINT = "http://28.244.56.144/evaluation-service/logs";

// Reusable log() function
async function log(stack, level, pkg, message) {
  try {
    const payload = {
      stack,
      level,
      package: pkg,
      message,
    };

    await axios.post(LOG_ENDPOINT, payload, {
      headers: {
        Authorization: "Bearer YOUR_ACCESS_TOKEN", // Replace if needed
      },
    });

    // optional: console.log("Logged:", message);
  } catch (err) {
    // fallback
    console.error("Logging failed:", err.message);
  }
}

module.exports = log;
