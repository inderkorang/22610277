import React, { useState } from 'react';
import { TextField, Button } from '@mui/material';
import axios from 'axios';
import { log } from '../utils/logger';

const StatsPage = () => {
  const [code, setCode] = useState("");
  const [stats, setStats] = useState(null);

  const fetchStats = async () => {
    try {
      const res = await axios.get(`http://localhost:8000/shorturls/${code}`);
      setStats(res.data);
      await log("debug", "page", `Fetched stats for ${code}`);
    } catch {
      await log("error", "api", "Stats fetch failed");
    }
  };

  return (
    <div>
      <h2>URL Stats</h2>
      <TextField label="Shortcode" value={code} onChange={e => setCode(e.target.value)} />
      <Button onClick={fetchStats} variant="contained" sx={{ ml: 2 }}>Fetch Stats</Button>

      {stats && (
        <div>
          <p><b>Original URL:</b> {stats.url}</p>
          <p><b>Created:</b> {stats.created}</p>
          <p><b>Expires:</b> {stats.expiry}</p>
          <p><b>Total Clicks:</b> {stats.totalClicks}</p>
        </div>
      )}
    </div>
  );
};

export default StatsPage;
