import React, { useState } from "react";
import axios from "axios";
import { TextField, Button, Typography, Grid } from "@mui/material";
import log from "../utils/logger";

const URLForm = () => {
  const [url, setUrl] = useState("");
  const [validity, setValidity] = useState("");
  const [shortcode, setShortcode] = useState("");
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    try {
      const res = await axios.post("http://localhost:8000/shorturls", {
        url,
        validity: Number(validity),
        shortcode,
      });

      setResult(res.data);
      await log("frontend", "debug", "component", "Short URL created.");
    } catch (err) {
      console.error(err);
      await log("frontend", "error", "component", "Failed to create short URL");
    }
  };

  return (
    <Grid container spacing={2} direction="column">
      <Grid item>
        <TextField label="Long URL" fullWidth value={url} onChange={(e) => setUrl(e.target.value)} />
      </Grid>
      <Grid item>
        <TextField label="Validity (minutes)" fullWidth value={validity} onChange={(e) => setValidity(e.target.value)} />
      </Grid>
      <Grid item>
        <TextField label="Custom Shortcode (optional)" fullWidth value={shortcode} onChange={(e) => setShortcode(e.target.value)} />
      </Grid>
      <Grid item>
        <Button variant="contained" color="primary" onClick={handleSubmit}>Shorten</Button>
      </Grid>
      {result && (
        <Grid item>
          <Typography>Short URL: <a href={result.shortLink} target="_blank" rel="noreferrer">{result.shortLink}</a></Typography>
          <Typography>Expires at: {result.expiry}</Typography>
        </Grid>
      )}
    </Grid>
  );
};

export default URLForm;
