import React from "react";
import URLForm from "./components/URLForm";
import { Container, Typography } from "@mui/material";

function App() {
  return (
    <Container>
      <Typography variant="h4" gutterBottom>URL Shortener</Typography>
      <URLForm />
    </Container>
  );
}

export default App;
