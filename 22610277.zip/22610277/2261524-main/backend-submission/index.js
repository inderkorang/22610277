const express = require("express");
const cors = require("cors");
const app = express();
const shortener = require("./routes/shortener");

app.use(cors());
app.use(express.json());
app.use("/shorturls", shortener);

app.get("/", (_, res) => {
  res.send("URL Shortener Backend is running.");
});

app.listen(8000, () => {
  console.log("Server running on http://localhost:8000");
});
