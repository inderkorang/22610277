const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');
const { saveLink, getLink } = require('./storage');
const { log } = require('../logging-middleware/logger');

function generateCode() {
  return uuid().slice(0, 5);
}

router.post('/', async (req, res) => {
  const { url, validity = 30, shortcode } = req.body;
  try {
    new URL(url); // Validate URL
  } catch {
    await log("backend", "error", "handler", "Invalid URL");
    return res.status(400).json({ error: "Invalid URL" });
  }

  const code = shortcode || generateCode();
  if (getLink(code)) {
    await log("backend", "warn", "handler", "Shortcode already in use");
    return res.status(409).json({ error: "Shortcode already in use" });
  }

  const now = Date.now();
  const expiry = new Date(now + validity * 60000).toISOString();

  saveLink(code, {
    url,
    created: new Date(now).toISOString(),
    expiry,
    clicks: [],
  });

  await log("backend", "debug", "handler", `Shortlink created: ${code}`);

  res.status(201).json({
    shortLink: `http://localhost:8000/${code}`,
    expiry
  });
});

router.get('/:code', async (req, res) => {
  const code = req.params.code;
  const data = getLink(code);

  if (!data) {
    await log("backend", "error", "handler", "Shortcode not found");
    return res.status(404).json({ error: "Shortcode not found" });
  }

  res.status(200).json({
    url: data.url,
    created: data.created,
    expiry: data.expiry,
    totalClicks: data.clicks.length,
    clickDetails: data.clicks
  });
});

module.exports = router;

