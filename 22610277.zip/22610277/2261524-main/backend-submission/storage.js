const db = {};

function saveLink(code, data) {
  db[code] = data;
}

function getLink(code) {
  return db[code];
}

module.exports = { saveLink, getLink };
