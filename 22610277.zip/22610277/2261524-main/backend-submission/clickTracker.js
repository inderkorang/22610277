const express = require('express');
const router = express.Router();
const { getLink } = require('./storage');
const { log } = require('../logging-middleware/logger');

router.get('/:code', async (req, res) => {
  const code = req.params.code;
  const data = getLink(code);

  if (!data) {
    await log("backend", "error", "route", "Shortcode not found");
    return res.status(404).send("Shortcode not found");
  }

  if (new Date(data.expiry) < new Date()) {
    await log("backend", "warn", "route", "Shortlink expired");
    return res.status(410).send("Link expired");
  }

  const click = {
    timestamp: new Date().toISOString(),
    referrer: req.get('Referer') || 'direct',
    location: 'IN' // mock geo
  };

  data.clicks.push(click);

  await log("backend", "debug", "route", `Redirected to: ${data.url}`);
  res.redirect(data.url);
});

module.exports = router;
