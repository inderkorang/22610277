const store = {};

function saveLink(code, data) {
  store[code] = data;
}

function getLink(code) {
  return store[code];
}

module.exports = { saveLink, getLink };
